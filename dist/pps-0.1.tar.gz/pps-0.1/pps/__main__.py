from .logic import main

main()